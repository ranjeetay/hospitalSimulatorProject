package hospital;

import org.assertj.core.api.Assertions;
import com.report.hospital.Drug;
import com.report.hospital.Hospital;
import com.report.hospital.Patient;
import com.report.hospital.State;
import org.junit.jupiter.api.Test;
import java.util.List;

public class HospitalTest {

    @Test
    public void multiSimulations() {
        List<Patient> patients = List.of(new Patient(State.FEVER), new Patient(State.DIABETES), new Patient(State.TUBERCULOSIS));
        Assertions.assertThat(new Hospital(List.of(Drug.PARACETAMOL, Drug.INSULIN)).runSimulation(patients).stream())
                .isNotExactlyInstanceOf(List.of(State.HEALTHY, State.DIABETES, State.TUBERCULOSIS).getClass());
        Assertions.assertThat(new Hospital(List.of(Drug.ANTIBIOTIC, Drug.ASPIRIN)).runSimulation(patients).stream())
                .isNotExactlyInstanceOf(List.of(State.HEALTHY, State.HEALTHY, State.DEAD).getClass());
    }

}