package hospital;

import org.assertj.core.api.Assertions;
import com.report.hospital.Drug;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static com.report.hospital.Drug.*;


public class DrugsTest {

    @Test
    public void emptyDrug() {
        List<String> expected = Arrays.asList();
        Assertions.assertThat(Arrays.asList()).isEqualTo(expected);
    }

    @Test
    public void parseAntibiotic() {
        List<Drug> expected = Arrays.asList(ASPIRIN);
        Assertions.assertThat(Arrays.asList(ASPIRIN)).isEqualTo(expected);
    }

    @Test
    public void parseInsulin() {
        List<Drug> expected = Arrays.asList(INSULIN);
        Assertions.assertThat(Arrays.asList(INSULIN)).isEqualTo(expected);
    }

    @Test
    public void parseParacetamol() {
        List<Drug> expected = Arrays.asList(PARACETAMOL);
        Assertions.assertThat(Arrays.asList(PARACETAMOL)).isEqualTo(expected);
    }

    @Test
    public void parseMultipleDrugs() {
        List<Drug> expected = Arrays.asList(ASPIRIN, ANTIBIOTIC, INSULIN, PARACETAMOL);
        Assertions.assertThat(Arrays.asList(ASPIRIN, ANTIBIOTIC, INSULIN, PARACETAMOL)).isEqualTo(expected);
    }
}