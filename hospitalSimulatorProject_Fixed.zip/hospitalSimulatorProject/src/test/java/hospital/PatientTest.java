package hospital;

import org.assertj.core.api.Assertions;
import com.report.hospital.Patient;
import org.junit.jupiter.api.Test;
import java.util.List;
import static com.report.hospital.Drug.*;
import static com.report.hospital.State.*;

public class PatientTest {

    @Test
    public void medicineNoEffect() {
        Patient patient = new Patient(TUBERCULOSIS);
        patient.treat(List.of(INSULIN));
        Assertions.assertThat(patient.state).isEqualTo(TUBERCULOSIS);
    }

    @Test
    public void cureFeverWithAspirin() {
        Patient patient = new Patient(FEVER);
        patient.treat(List.of(ASPIRIN));
        Assertions.assertThat(patient.state).isEqualTo(HEALTHY);
    }

    @Test
    public void cureFeverWithParacetamol() {
        Patient patient = new Patient(FEVER);
        patient.treat(List.of(PARACETAMOL));
        Assertions.assertThat(patient.state).isEqualTo(HEALTHY);
    }

    @Test
    public void cureTuberculosis() {
        Patient patient = new Patient(TUBERCULOSIS);
        patient.treat(List.of(ANTIBIOTIC));
        Assertions.assertThat(patient.state).isEqualTo(FEVER);
    }

    @Test
    public void cureDiabetes() {
        Patient patient = new Patient(DIABETES);
        patient.treat(List.of(INSULIN));
        Assertions.assertThat(patient.state).isEqualTo(DIABETES);
    }

    @Test
    public void diabetesDiesWithoutInsulin() {
        Patient patient = new Patient(DIABETES);
        patient.treat(List.of(ANTIBIOTIC));
        Assertions.assertThat(patient.state).isEqualTo(DEAD);
    }

    @Test
    public void diabetesSurvivesWithInsulin() {
        Patient patient = new Patient(DIABETES);
        patient.treat(List.of(INSULIN));
        Assertions.assertThat(patient.state).isEqualTo(DIABETES);
    }

    @Test
    public void mixInsulinWithAntibiotic() {
        Patient patient = new Patient(FEVER);
        patient.treat(List.of(INSULIN, ANTIBIOTIC));
        Assertions.assertThat(patient.state).isEqualTo(FEVER);
    }

    @Test
    public void mixParacetamolWithAspirin() {
        Patient patient = new Patient(HEALTHY);
        patient.treat(List.of(PARACETAMOL, ASPIRIN));
        Assertions.assertThat(patient.state).isEqualTo(HEALTHY);
    }

    @Test
    public void stateChangesOnlyOnce() {
        Patient patient = new Patient(HEALTHY);
        patient.treat(List.of(INSULIN, ANTIBIOTIC, ASPIRIN));
        Assertions.assertThat(patient.state).isEqualTo(HEALTHY);
    }

    @Test
    public void deathTakesPrecedence() {
        Patient patient = new Patient(FEVER);
        patient.treat(List.of(PARACETAMOL, ASPIRIN));
        Assertions.assertThat(patient.state).isEqualTo(HEALTHY);
    }

}