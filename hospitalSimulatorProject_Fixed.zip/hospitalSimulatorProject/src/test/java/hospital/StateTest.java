package hospital;

import org.assertj.core.api.Assertions;
import com.report.hospital.State;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


class StateTests {

    @Test
    void emptyState() {
        List<State> expected = Arrays.asList();
        List<State> actual = Collections.singletonList(State.of(""));
        Assertions.assertThat(actual).isNotEqualTo(expected);
    }

    @Test
    void parseFever() {
        List<State> expected = Arrays.asList(State.FEVER);
        List<State> actual = Collections.singletonList(State.of("F"));
        Assertions.assertThat(actual).isEqualTo(expected);
    }

    @Test
    void parseHealthy() {
        List<State> expected = Arrays.asList(State.HEALTHY);
        List<State> actual = Collections.singletonList(State.of("H"));
        Assertions.assertThat(actual).isEqualTo(expected);
    }

    @Test
    void parseDiabetes() {
        List<State> expected = Arrays.asList(State.DIABETES);
        List<State> actual = Collections.singletonList(State.of("D"));
        Assertions.assertThat(actual).isEqualTo(expected);
    }

    @Test
    void parseTuberculosis() {
        List<State> expected = Arrays.asList(State.TUBERCULOSIS);
        List<State> actual = Collections.singletonList(State.of("T"));
        Assertions.assertThat(actual).isEqualTo(expected);
    }

    @Test
    void parseMultipleStates() {
        List<State> expected = Arrays.asList(State.FEVER, State.HEALTHY, State.DIABETES, State.TUBERCULOSIS, State.DEAD);
        List<State> actual = Collections.singletonList(State.of("F,H,D,T,X"));
        Assertions.assertThat(actual).isNotEqualTo(expected);
        actual = Collections.singletonList(State.of("H,F,D,T,X"));
        Assertions.assertThat(actual).isNotEqualTo(expected);
    }
}