package hospital;

import org.assertj.core.api.Assertions;
import com.report.hospital.Main;
import org.junit.jupiter.api.Test;

public class IntegrationTest {

    @Test
    public void invalidArguments() {
        Assertions.assertThatExceptionOfType(IllegalArgumentException.class)
                .isThrownBy(() -> Main.main(new String[]{""}));
    }

    @Test
    public void emptyArguments() {
        Assertions.assertThat(Main.report(new String[]{"", ""}).toString().replaceAll("([\\r\\n])", "")).isEqualTo("F:0,H:0,D:0,T:0,X:0");
    }

    @Test
    public void noPatientsMultiDrugs() {
        Assertions.assertThat(Main.report(new String[]{"", "P,As"}).toString().replaceAll("([\\r\\n])", "")).isEqualTo("F:0,H:0,D:0,T:0,X:0");
    }

    @Test
    public void onePatient() {
        Assertions.assertThat(Main.report(new String[]{"D,D", ""}).toString().replaceAll("([\\r\\n])", "")).isEqualTo("F:0,H:0,D:0,T:0,X:2");
    }

    @Test
    public void onePatientNoDrug() {
        Assertions.assertThat(Main.report(new String[]{"F", ""}).toString().replaceAll("([\\r\\n])", "")).isEqualTo("F:1,H:0,D:0,T:0,X:0");
    }

    @Test
    public void onePatientOneDrug() {
        Assertions.assertThat(Main.report(new String[]{"F", "P"}).toString().replaceAll("([\\r\\n])", "")).isEqualTo("F:0,H:1,D:0,T:0,X:0");
    }

    @Test
    public void multiPatientsNoDrugs() {
        Assertions.assertThat(Main.report(new String[]{"D,D", ""}).toString().replaceAll("([\\r\\n])", "")).isEqualTo("F:0,H:0,D:0,T:0,X:2");
    }

    @Test
    public void multiPatientsMultiDrugs() {
        Assertions.assertThat(Main.report(new String[]{"F,D,T", "An,I"}).toString().replaceAll("([\\r\\n])", "")).isEqualTo("F:2,H:0,D:1,T:0,X:0");
    }
}