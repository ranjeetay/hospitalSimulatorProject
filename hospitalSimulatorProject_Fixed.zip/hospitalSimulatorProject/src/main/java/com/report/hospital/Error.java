package com.report.hospital;

public enum Error {
    NO_REPORT, NO_STATE;
}